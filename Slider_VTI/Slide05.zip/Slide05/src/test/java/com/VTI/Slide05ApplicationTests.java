package com.VTI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Slide05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
