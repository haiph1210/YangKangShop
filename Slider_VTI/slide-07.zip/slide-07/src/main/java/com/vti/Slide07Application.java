package com.vti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slide07Application {

	public static void main(String[] args) {
		SpringApplication.run(Slide07Application.class, args);
	}

}
