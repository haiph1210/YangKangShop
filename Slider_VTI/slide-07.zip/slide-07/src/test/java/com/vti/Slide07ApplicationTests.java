package com.vti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Slide07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
